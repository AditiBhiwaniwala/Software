from django.apps import AppConfig


class XyzConfig(AppConfig):
    name = 'xyz'
