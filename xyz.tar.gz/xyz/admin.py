from django.contrib import admin
from .models import signup_db,fooditem_db,comment
# Register your models here.
admin.site.register(signup_db)
admin.site.register(fooditem_db)
admin.site.register(comment)
