import text,yaml
from django.http import HttpResponse
from django.shortcuts import render, render_to_response
from xyz.models import signup_db,fooditem_db,comment
from django.core.context_processors import csrf
from django.views.decorators.csrf import csrf_protect
from django.template import RequestContext
from django.contrib.auth import authenticate, login
from text1 import sentiment
from django.core.mail import EmailMessage,send_mail
foodid1=0
def home(request):
   c={}
   c={'error':'Please log in to continue'}
   c.update(csrf(request))
   return render_to_response('logged_in.html',c)

def signup1(request):
   c={}
   c.update(csrf(request))
   return render_to_response('signup.html',c)

def login1(request):
   c={}
   c.update(csrf(request))
   return render_to_response('login.html',c)

def logout1(request):
   request.session.flush()
   c={}
   c.update(csrf(request))
   return render_to_response('logged_in.html',c)

@csrf_protect
def sign(request):
    c={}
    
    #c.update(csrf(request))
    csrfContext = RequestContext(request)
    if request.method == 'POST':
              post = request.POST
              name = post['uname']
              password = post['pass']
              hostel_name = post['hname']
              contact = post['contact']
              id_= post['id']
              print name,type(name)
              print id_,type(id_)
              
              f = signup_db(name=name,id_num=id_,hostel_number=hostel_name,password=password,department="cse",contact_number=contact)
              f.save()
    return render_to_response('login.html',c,csrfContext)

def login(request):
	if request.method == 'POST':
		stud_id = request.POST.get('uname','')
		password1 = request.POST.get('pass','')
		#request.session['stud_id'] = stud_id
		#request.session['stud_password'] = password 
		user = signup_db.objects.filter(id_num=stud_id, password=password1)
		if len(user)==0:
			c = {'msg':'ID or password incorrect'}
			c.update((csrf(request)))
			return render_to_response('login.html',c)
		#user = Student.objects.filter(unique_id=stud_id, password=password).first()
		#assgnAnsList = AssignmentA.objects.filter(unique_id=user)
		#par = {'uname':Student.objects.filter(unique_id=stud_id).first(), 
		#'subjList':StudSub.objects.filter(stud_id=stud_id),'uid':stud_id,'assgnAnsList':assgnAnsList}
		#par.update(csrf(request))
		print user.first().name
                request.session['idno']=stud_id
                request.session['name']=user.first().name
		c={'idno':stud_id,'name':user.first().name}
		c.update((csrf(request)))
        return render_to_response('logged_in.html',c)

def canteen(request):
   c={'query_set':fooditem_db.objects.filter(hostel_number=1)}
   #c.update(csrf(request))
   csrfContext = RequestContext(request)
   return render_to_response('canteen.html',c,csrfContext)



def boysmess(request):
   c={'query_set':fooditem_db.objects.filter(hostel_number=3)}
   #c.update(csrf(request))
   csrfContext = RequestContext(request)
   return render_to_response('boysmess.html',c,csrfContext)

def girlsmess(request):
   c={'query_set':fooditem_db.objects.filter(hostel_number=2)}
   #c.update(csrf(request))
   csrfContext = RequestContext(request)
   return render_to_response('girlsmess.html',c,csrfContext)

def commenti(request):
    c={}
    #c.update(csrf(request))
    csrfContext = RequestContext(request)
    if request.method == 'POST':
              post = request.POST
	      global foodid1
              foodid1 = post['foodid']
              comments = comment.objects.filter(id_pro=foodid1)
              cont=fooditem_db.objects.filter(id_pro=foodid1)
	      a=cont.first()
              #chartdata = {'POSITIVE': a.positive, 'NEGATIVE': a.negative, 'NEUTRAL': a.neutral}
              
   	      c={'query_set':comments,'POSITIVE': a.positive, 'NEGATIVE': a.negative, 'NEUTRAL': a.neutral}
   
   
    return render_to_response('comment.html',c,csrfContext )
   
def insertcomment(request):
    c={}
    #c.update(csrf(request))
    csrfContext = RequestContext(request)
    if request.method == 'POST':
              post = request.POST
              name = post['Text1']
	      global foodid1
	      c={'foodid1':foodid1}
              s=fooditem_db.objects.filter(id_pro=foodid1)
              a=s.first()
              if not request.session.get('idno', None):
			#return HttpResponseRedirect('/please log in to comment/')
                        print ("here")
                        c={'error':'Please log in to continue'}
                        #c.update(csrf(request))
			return render_to_response('logged_in.html',c,csrfContext)
              sent=sentiment(name)
              x=comment.objects.filter(id_pro=foodid1)
              rating=(a.rating*len(x)+sent)/(len(x)+1)
	      fooditem_db.objects.filter(id_pro=foodid1).update(rating=rating)
              if(sent>0.0):
                    fooditem_db.objects.filter(id_pro=foodid1).update(positive=a.positive+1)
		    
              elif(sent<0.0):
		    fooditem_db.objects.filter(id_pro=foodid1).update(negative=a.negative+1)
	      else:
		    fooditem_db.objects.filter(id_pro=foodid1).update(neutral=a.neutral+1)
	      s=fooditem_db.objects.filter(id_pro=foodid1)
              a=s.first()
              negative=a.negative
	      print(negative)
              print(len(x))
              print(float(negative)/(len(x)+1))
              if((float(negative)/(len(x)+1))>=0.3):
                    print ("here")
                    send_mail(a.foodname,'Rating for this product is very low . Please take appropriate 					action','akolarocks2@gmail.com',['aditi.bhiwaniwala@gmail.com'],fail_silently=False)

              #s.update(rating=rating)
              #s.save()
              print(rating)
	      #foodid2=1
	      
	      	
              f = comment(id_pro_id=foodid1,comment=name,id_num_id=request.session['idno'])
              f.save()
              comments = comment.objects.filter(id_pro=foodid1)
              cont=fooditem_db.objects.filter(id_pro=foodid1)
	      a=cont.first()
              #chartdata = {'POSITIVE': a.positive, 'NEGATIVE': a.negative, 'NEUTRAL': a.neutral}
              
   	      c={'query_set':comments,'POSITIVE': a.positive, 'NEGATIVE': a.negative, 'NEUTRAL': a.neutral}
    return render_to_response('comment.html',c)
  
   
