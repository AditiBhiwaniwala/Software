from django.conf.urls import  include, url
from . import views
urlpatterns = [
    # Examples:
    # url(r'^$', 'the.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^$', views.home, name='home'),
     url(r'^signup/$', views.sign, name='signup'),
     url(r'^login/$', views.login, name='login'),
     url(r'^signup1/$', views.signup1, name='signup'),
     url(r'^login1/$', views.login1, name='login'),
     url(r'^logout/$', views.logout1, name='logout'),
     url(r'^canteen/$', views.canteen, name='canteen'),
     url(r'^login/canteen/$',views.canteen , name='canteen'),
     url(r'^boysmess/$',views.boysmess , name='boysmess'),	
     url(r'^girlsmess/$',views.girlsmess , name='girlsmess'),
     url(r'^login/boysmess/$',views.boysmess , name='boysmess'),	
     url(r'^login/girlsmess/$',views.girlsmess , name='girlsmess'),
     url(r'^logout/boysmess/$',views.boysmess , name='boysmess'),	
     url(r'^logout/girlsmess/$',views.girlsmess , name='girlsmess'),
     url(r'^logout/canteen/$',views.canteen , name='canteen'),
     url(r'^canteen/comment/$',views.commenti , name='comment'),
     url(r'^login/canteen/comment/$',views.commenti , name='comment'),
     url(r'^login/canteen/comment/insertcomm/$',views.insertcomment,name='insertcomment')
     
]

