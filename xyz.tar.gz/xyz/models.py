from __future__ import unicode_literals

from django.db import models
from django.db.models.fields.files import ImageField

# Create your models here.
class signup_db(models.Model):
	name=models.CharField(max_length=255)
	id_num=models.IntegerField(primary_key=True)	
	hostel_number=models.CharField(max_length=255)
	password=models.CharField(max_length=255)
	department=models.CharField(max_length=255)
	contact_number=models.IntegerField()
        def __str__(self):
             return str(self.id_num)


#class food_db(models.Model):
       #foodname=models.CharField(max_length=255)
       #foodimg=models.

    
class fooditem_db(models.Model):
       hostel_number=models.CharField(max_length=255, default="3")
       foodname=models.CharField(max_length=255)
       id_pro= models.AutoField(primary_key=True)
       image = models.ImageField(upload_to='images')
       rating=models.FloatField(default=0.0)
       positive=models.IntegerField(default=0)
       negative=models.IntegerField(default=0)
       neutral=models.IntegerField(default=0)
       def __str__(self):
             return str(self.id_pro)

class comment(models.Model):
      id_pro= models.ForeignKey('fooditem_db')
      comment=models.TextField()
      id_num= models.ForeignKey('signup_db')
      def __str__(self):
             return str(self.id_pro) +'/' +str(self.id_num)

